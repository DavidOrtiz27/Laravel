<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ciudad extends Model
{
    protected $table = 'ciudades';
    protected $fillable = [
        'nombre'
    ];

    // Relación con pacientes
    public function pacientes()
    {
        return $this->hasMany(Pacientes::class, 'ciudad_id');
    }

    // Relación con médicos
    public function Medico()
    {
        return $this->hasMany(Medico::class, 'ciudad_id');
    }

    // Relación con consultorios
    public function consultorios()
    {
        return $this->hasMany(Consultorios::class, 'ciudad_id');
    }
}
