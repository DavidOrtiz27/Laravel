<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Afiliacion extends Model
{
    protected $table = 'afiliaciones';
    protected $fillable = [
        'paciente_id',
        'aseguradora_id',
        'fecha_inicio',
        'fecha_fin',
        'estado'
    ];

    // Un paciente puede tener varias afiliaciones
    public function paciente()
    {
        return $this->belongsTo(Pacientes::class, 'paciente_id');
    }

    // Una aseguradora puede tener varias afiliaciones
    public function aseguradora()
    {
        return $this->belongsTo(Aseguradora::class, 'aseguradora_id');
    }
}
