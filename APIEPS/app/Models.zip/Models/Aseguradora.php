<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Aseguradora extends Model
{
    protected $table = 'aseguradoras';
    protected $fillable = [
        'nombre',
        'nit',
        'direccion',
        'telefono',
        'email',
        'ciudad_id'
    ];

    // Una aseguradora puede tener muchas afiliaciones
    public function afiliaciones()
    {
        return $this->hasMany(Afiliacion::class, 'aseguradora_id');
    }

    // Relación indirecta: una aseguradora tiene muchos pacientes a través de afiliaciones
    public function pacientes()
    {
        return $this->hasManyThrough(
            Pacientes::class,
            Afiliacion::class,
            'aseguradora_id', // FK en Afiliaciones
            'id',            // PK en Pacientes
            'id',            // PK en Aseguradoras
            'paciente_id'     // FK en Afiliaciones
        );
    }
}
