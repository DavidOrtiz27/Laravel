<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Paciente extends Model
{
    protected $table = 'pacientes';
    protected $fillable = [
        'ciudad_id',
        'nombre',
        'documento',
        'telefono',
        'email',
        'direccion'
    ];

    // Paciente.php
    public function afiliaciones() { return $this->hasMany(Afiliacion::class, 'paciente_id'); }

    // Relación con ciudad
    public function ciudad()
    {
        return $this->belongsTo(Ciudades::class, 'ciudad_id');
    }

    // Relación con citas
    public function citas()
    {
        return $this->hasMany(Citas::class, 'paciente_id');
    }

    // Relación con historia clínica
    public function historiaClinica()
    {
        return $this->hasOne(HistoriasClinicas::class, 'paciente_id');
    }

    // Relación con facturas
    public function facturas()
    {
        return $this->hasMany(Facturas::class, 'paciente_id');
    }

    // Relación con consultas médicas
    public function consultasMedicas()
    {
        return $this->hasMany(ConsultasMedicas::class, 'paciente_id');
    }
}
