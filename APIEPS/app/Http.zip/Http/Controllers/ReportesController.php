<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cita;
use App\Models\Medico;
use App\Models\Paciente;
use App\Models\HistoriaClinica;
use App\Models\Especialidad;

class ReportesController extends Controller
{
    /**
     * 1️⃣ Listar todas las citas con paciente, médico, especialidad y consultorio
     */
    public function listarCitas()
    {
        $citas = Cita::with(['paciente', 'medico', 'especialidad', 'consultorio'])->get();
        return response()->json($citas);
    }

    /**
     * 2️⃣ Obtener todos los médicos de una especialidad específica
     */
    public function medicosPorEspecialidad($especialidadId)
    {
        $medicos = Medico::where('especialidad_id', $especialidadId)
            ->with('especialidad')
            ->get();

        return response()->json($medicos);
    }

    /**
     * 3️⃣ Listar pacientes con sus afiliaciones y aseguradoras
     */
    public function pacientesConAfiliaciones()
    {
        $pacientes = Paciente::with(['afiliaciones.aseguradora'])->get();
        return response()->json($pacientes);
    }

    /**
     * 4️⃣ Consultar las citas pendientes de un médico específico
     */
    public function citasPendientesMedico($medicoId)
    {
        $citasPendientes = Cita::where('medico_id', $medicoId)
            ->where('estado', 'pendiente')
            ->with(['paciente', 'consultorio', 'especialidad'])
            ->get();

        return response()->json($citasPendientes);
    }

    /**
     * 5️⃣ Obtener las historias clínicas de un paciente
     */
    public function historiasClinicasPaciente($pacienteId)
    {
        $historias = HistoriaClinica::where('paciente_id', $pacienteId)
            ->with('paciente')
            ->get();

        return response()->json($historias);
    }
}
